<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    use HasFactory;

    protected $fillable = [
        'exam_id',
        'materi',
        'indikator',
        'cognitive_level',
        'bobot',
        'type',
        'question_text',
        'image',
        'option_a',
        'option_b',
        'option_c',
        'option_d',
        'correct_option',
        'explanation',
        'pair_data',
        'sequence_data',
        'wrong_answer_data',
    ];

    protected $casts = [
        'pair_data' => 'array',
        'sequence_data' => 'array',
        'wrong_answer_data' => 'array',
    ];

    public function exam()
    {
        return $this->belongsTo(Exam::class);
    }
}
